# PiicoDev® Air Quality Sensor ENS160

<!-- TODO update link URL with CE SKU -->
<!-- TODO update link title -->
<!-- TODO put image in Documents directory. Piicodev image 1500x1000 resize to 30% -> 450x300 -->
![](Documents/showcase-render.png)

This is the hardware repo for the Core Electronics [PiicoDev Air Quality Sensor ENS160](https://core-electronics.com.au/catalog/product/view/sku/CE08560).

<!-- TODO populate below here from the tutorial -->

## License
This project is open source - please review the LICENSE.md file for further licensing information.

If you have any technical questions, or concerns about licensing, please contact technical support on the [Core Electronics forums](https://forum.core-electronics.com.au/).

## Attribution
<!-- TODO Confirm attribution eg
The hardware design of this module is influenced by the design from [Sparkfun](https://github.com/sparkfun/Qwiic_Capacitive_Touch_Slider_CAP1203).  -->

*\"PiicoDev\" and the PiicoDev logo are trademarks of Core Electronics Pty Ltd.*
